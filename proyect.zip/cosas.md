de 0 a 75 años

vamos a pedir la fecha de nacimiento.
vamos a seleccionar modos
vamos a hacer dos modos
A-> meses, 36 meses por fila = 3 años
-marca cuando nazca, cuando cumpla 30 años y 60 años y cuando se muera
B-> semanas, 52 semanas por fila -> fila = 1 año
-en el eje x mostrará las semanas por multiplos de 5
-en el eje y mostará los años por multiplos de 5

--- TECNICO

tenemos que saber como restar fechas. fechaNacimiento - fechaActual en semanas y en años
maquetar cuadritos/bolitas
